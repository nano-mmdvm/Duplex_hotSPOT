<?php
# This is an auto-generated config-file!
# Be careful, when manual editing this!

date_default_timezone_set('Europe/London');
define("MMDVMLOGPATH", "/var/log/pi-star");
define("MMDVMLOGPREFIX", "MMDVM");
define("MMDVMINIPATH", "/etc");
define("MMDVMINIFILENAME", "mmdvmhost");
define("MMDVMHOSTPATH", "/usr/local/bin");
define("DMRIDDATPATH", "/usr/local/etc");
define("YSFGATEWAYLOGPATH", "/var/log/pi-star");
define("YSFGATEWAYLOGPREFIX", "YSFGateway");
define("YSFGATEWAYINIPATH", "/etc");
define("YSFGATEWAYINIFILENAME", "ysfgateway");
define("P25GATEWAYLOGPATH", "/var/log/pi-star");
define("P25GATEWAYLOGPREFIX", "P25Gateway");
define("P25GATEWAYINIPATH", "/etc");
define("P25GATEWAYINIFILENAME", "p25gateway");
define("LINKLOGPATH", "/var/log/pi-star");
define("IRCDDBGATEWAY", "ircddbgatewayd");
define("REFRESHAFTER", "30");
define("TEMPERATUREHIGHLEVEL", "");
define("REBOOTMMDVM", "");
define("REBOOTSYS", "");
define("HALTSYS", "");
?>
